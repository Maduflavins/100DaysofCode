def collect_phone_number():
    phone_number = input("type your number: ").strip()
    while not phone_number.isdigit() or len(phone_number) != 11:
        print('Invalid Phone number')
        phone_number = input("type your number: ").strip()

    return phone_number

def collect_name():
    name = input("type your name[or q to quit]: ").strip().lower()
    while not name.isalpha():
        print('Invalid Name!')
        name = input("type your name[or q to quit]: ").strip().lower()
        
    return name

def store_contacts():
    global contacts

    print('STORAGE MODE')
    
    #create contacts dictinary
    contacts = {}

    while True:
        name = collect_name()
        if name == 'quit' or name == 'q':
            break

        # collect phone number with function
        phone_number = collect_phone_number()
        
        contacts[name] = phone_number

def retrieve_contact():
    print('\nRETRIVAL MODE')
    while True:
        name = collect_name()
        if name == 'quit' or name == 'q':
            break

        try:
            print(name, contacts[name])

        except:
            print('Key does  not exist')

def main():    
    #collect and store contacts in dictionary    
    store_contacts()
    print(f"contacts = {contacts}")

    #helps to retrieve a contact by a given name
    retrieve_contact()

if __name__ == '__main__':
    main()
    
